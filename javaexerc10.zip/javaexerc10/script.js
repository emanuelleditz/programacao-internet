let inputlargura = document.querySelector ("#largura");
let inputcomprimento = document.querySelector ("#comprimento");
let btCalcular = document.querySelector ("#btCalcular");
let h3Resultado = document.querySelector ("#h3Resultado");

function CalcularArea() {
    let largura = Number(inputlargura.value);
    let comprimento = Number(inputcomprimento.value);
    let area = largura * comprimento;
    
    h3Resultado.innerHTML = "A área do terreno é: " + area + "m²";
}
btCalcular.onclick = function() {
    CalcularArea();
}