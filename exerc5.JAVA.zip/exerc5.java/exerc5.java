import java.util.Scanner;

public class exerc5 {
    
    public static void main(String[] args){
        
        int num;
        Scanner s = new Scanner(System.in);
        String resultado = "Numero par";

        System.out.print("Informe o primeiro número: ");
        num = s.nextInt();

        if(num % 2 != 0){
            resultado = "Numero impar";
        }
        System.out.print("Resultado: " + resultado);
    }
}
