import java.util.Scanner;

public class exerc7 {
    public static void main(String[] args){

        int num1, num2;
        Scanner s = new Scanner(System.in);

        System.out.print("Informe o primeiro número: ");
        num1 = s.nextInt();
        System.out.print("Informe o segundo número: ");
        num2 = s.nextInt();

        System.out.println("Resultado das comparações entre os numeros informados: ");
        System.out.println("num1 > num2: " + (num1 > num2));
        System.out.println("num1 < num2: " + (num1 < num2));
        System.out.println("num1 == num2: " + (num1 == num2));
        System.out.println("num1 != num2: " + (num1 != num2));

    }    
}
