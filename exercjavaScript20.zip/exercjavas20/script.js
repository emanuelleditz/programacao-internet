let inputtamP = document.querySelector ("#tamP");
let inputtamM = document.querySelector ("#tamM");
let inputtamG = document.querySelector ("#tamG");
let btCalcular = document.querySelector ("#btCalcular");
let h3Resultado = document.querySelector ("#h3Resultado");

function Calcular (){
    let tamP = Number (inputtamP.value);
    let tamM = Number (inputtamM.value);
    let tamG = Number (inputtamG.value);

    let resultado = (tamP * 10) + (tamM * 12) + (tamG * 15);

    h3Resultado.innerHTML = "Valor total a pagar &eacute;: " + resultado.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

btCalcular.onclick = function(){
    Calcular();
}