let inputdia = document.querySelector ("#dia");
let inputmes = document.querySelector ("#mes");
let btCalcular = document.querySelector ("#btCalcular");
let h3Resultado = document.querySelector ("#h3Resultado");

function Calcular (){
    let dia = Number (inputdia.value);
    let mes = Number (inputmes.value);

    let resultado = (mes - 1) * 30 + dia;

    h3Resultado.innerHTML = "Se passaram: " + resultado + " dias";
}

btCalcular.onclick = function(){
    Calcular();
}