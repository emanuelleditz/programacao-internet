let inputSabor1 = document.querySelector ("#Sabor1");
let inputSabor2 = document.querySelector ("#Sabor2");
let inputSabor3 = document.querySelector ("#Sabor3");
let inputSabor4 = document.querySelector ("#Sabor4");
let inputRefri = document.querySelector ("#Refri");
let btFzpedido = document.querySelector ("#btFzpedido");
let h3Resultado = document.querySelector ("#h3Resultado");

function calcularPedido(){
    let Sabor1 = inputSabor1.value;
    let Sabor2 = inputSabor2.value;
    let Sabor3 = inputSabor3.value;
    let Sabor4 = inputSabor4.value;
    let Refri = Number (inputRefri.value);

    let precoPizza = 12.00;
    let precoRefri = 7.00;

    let total = (4 * precoPizza) + (Refri * precoRefri);

    h3Resultado.innerHTML = 
    "Sabores escolhidos:" + "<br>" +
    "-" + Sabor1 +  "<br>" +
    "-" + Sabor2 + "<br>" +
    "-" + Sabor3 + "<br>" +
    "-" + Sabor4 + "<br>" +
    "Quantidade de refrigerantes:" + Refri + "<br>" +
    "Valor Total: R$" + total.toFixed(2);

}

btFzpedido.onclick = function(){
    calcularPedido();
}