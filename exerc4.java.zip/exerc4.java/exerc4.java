import java.util.Scanner;

public class exerc4{

public static void main(String[] args){

    int num1, num2;
    Scanner s = new Scanner(System.in);
    String resultado = "Números são iguais";

    System.out.print("Informe o primeiro número: ");
    num1 = s.nextInt();
    System.out.print("Informe o segundo número: ");
    num2 = s.nextInt();

    if(num1 > num2){ //expressão com resultado lógico
        //quando resultado for verdadeiro
        resultado = "Num1 é maior que num2";
        }else if(num1 < num2){
        //quando resultado for verdadeiro
        resultado = "Num1 é menor que num2";
     }else {
        //quando resultado for falso
        resultado = "Números são iguais";
     }
     System.out.println("Resultado: " + resultado);
    }
}