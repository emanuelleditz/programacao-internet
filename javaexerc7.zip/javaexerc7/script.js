let inputPessoas = document.querySelector ("#Pessoas");
let btCalcular = document.querySelector ("#btCalcular");
let h3Resultado = document.querySelector ("#h3Resultado");

btCalcular.onclick = function(){
    let Pessoas = Number(inputPessoas.value);

    if (isNaN(Pessoas) || Pessoas <= 0){
        h3Resultado.textContent = "Digite um número válido de pessoas!";
        return;
    }
    
    let ovos = Pessoas * 2;
    let queijo = Pessoas * 50;

    h3Resultado.innerHTML = 
    "Você vai precisar de: " + "<br>" +
    ovos + "Ovos <br> E" + "<br>" +
    queijo + "Gramas de Queijo";
}
