package unipar.com.trabalhov2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Trabalhov2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
