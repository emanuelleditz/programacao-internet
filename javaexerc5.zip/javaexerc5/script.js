let inputnum1 = document.querySelector("#num1");
let inputnum2 = document.querySelector("#num2");
let inputnum3 = document.querySelector("#num3");
let btMedia = document.querySelector("#btMedia");
let h3Resultado = document.querySelector("#h3Resultado");

function CalcularMedia(){
    let num1 = Number(inputnum1.value);
    let num2 = Number(inputnum2.value);
    let num3 = Number(inputnum3.value);
    let mediaAritmetica = (num1 + num2 + num3) /3;
    let mediaPonderada = (num1 * 3) + (num2 * 2) + (num3 * 5) / (3 + 2 + 5);
    let somaMedias = mediaAritmetica + mediaPonderada;
    let mediaDasMedias = somaMedias / 2;

    h3Resultado.textContent = 
    "Media Aritmetica:" + mediaAritmetica.toFixed(2) +"\n" +
    "Media Ponderada:" + mediaPonderada.toFixed(2) +"\n" +
    "Soma das medias:" + somaMedias.toFixed(2) +"\n" +
    "Media das medias:" + mediaDasMedias.toFixed(2);
}
btMedia.onclick = function(){
    CalcularMedia();
}