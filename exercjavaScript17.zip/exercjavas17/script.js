let inputvalor1 = document.querySelector ("#valor1");
let btCalcular = document.querySelector ("#btCalcular");
let h3Resultado = document.querySelector ("#h3Resultado");

function verificarParOuImpar() {
    let valor1 = Number (inputvalor1.value);

  if (valor1 % 2 === 0) {
    h3Resultado.innerHTML = "Par";
  } else {
    h3Resultado.innerHTML = "&Iacute;mpar";
  }
}

btCalcular.onclick = function(){
    verificarParOuImpar();
}