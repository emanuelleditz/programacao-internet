let inputNum1 = document.querySelector ("#Num1");
let inputNum2 = document.querySelector ("#Num2");
let btCalcular = document.querySelector ("#btCalcular");
let h3Resultado = document.querySelector ("#h3Resultado");

function calcularOperacoes(){
    let Num1 = Number (inputNum1.value);
    let Num2 = Number (inputNum2.value);

    let soma = Num1 + Num2;
    let subtracao = Num1 - Num2;
    let multiplicacao = Num1 * Num2;
    let divisao = Num2 !== 0? (Num1 / Num2).toFixed(2) : "Divisão por zero";

    h3Resultado.innerHTML = 
    "Soma:" + soma + "<br>" +
    "Subtração:" + subtracao + "<br>" +
    "Multiplicação:" + multiplicacao + "<br>" +
    "Divisão:" + divisao;
}

btCalcular.onclick = function(){
    calcularOperacoes();
}