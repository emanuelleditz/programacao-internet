let inputpreco = document.querySelector ("#preco");
let inputvalor = document.querySelector ("#valor");
let btCalcular = document.querySelector ("#btCalcular");
let h3Resultado = document.querySelector ("#h3Resultado");

function Calcularlitros(){
    let preco = Number (inputpreco.value);
    let valor = Number (inputvalor.value);

    if (preco > 0){
        let litros = valor / preco;
        h3Resultado.innerHTML = "Voc&ecirc; conseguiu colocar " + litros + " litros de gasolina!";
    }
    else{
        h3Resultado.innerHTML = "Por favor, insira um número válido!";
    }
}

btCalcular.onclick = function(){
    Calcularlitros();
}