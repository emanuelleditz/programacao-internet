let inputNome = document.querySelector ("#Nome");
let inputIdade = document.querySelector ("#Idade")
let btCalcular = document.querySelector ("#btCalcular");
let h3Resultado = document.querySelector ("#h3Resultado");

function DiasDeVida() {
    let Nome = inputNome.value;
    let Idade = inputIdade.value;
    
    let diasVividos = Idade * 365;

    h3Resultado.innerHTML = Nome + ", Voc&ecirc; j&aacute; viveu: " + diasVividos + " Dias";
}
btCalcular.onclick = function() {
    DiasDeVida();
}