let inputValor1 = document.querySelector ("#Valor1");
let inputValor2 = document.querySelector ("#Valor2");
let btValidar = document.querySelector ("#btValidar");
let h3Resultado = document.querySelector ("#h3Resultado");

function maiorNumero(){
    let Valor1 = Number(inputValor1.value);
    let Valor2 = Number(inputValor2.value);
    let resultado;

    if(Valor1 > Valor2){
        resultado = Valor1
    } else{
        resultado = Valor2
    }
    
    h3Resultado.innerHTML = "O valor maior &eacute: " + resultado;
}

btValidar.onclick = function() {
    maiorNumero();
}