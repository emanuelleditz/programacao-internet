let inputvalor1 = document.querySelector ("#valor1");
let inputvalor2 = document.querySelector ("#valor2");
let inputvalor3 = document.querySelector ("#valor3");
let inputvalor4 = document.querySelector ("#valor4");
let btCalcular = document.querySelector ("#btCalcular");
let h3Resultado = document.querySelector ("#h3Resultado");

function CalcularNumero(){
    let valor1 = Number (inputvalor1.value);
    let valor2 = Number (inputvalor2.value);
    let valor3 = Number (inputvalor3.value);
    let valor4 = Number (inputvalor4.value);

    let resultado = Math.min(valor1, valor2, valor3, valor4);

    h3Resultado.innerHTML = "O menor valor &eacute; " + resultado;
}

btCalcular.onclick = function(){
    CalcularNumero();
}