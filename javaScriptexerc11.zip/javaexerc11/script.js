let inputcavalos = document.querySelector ("#cavalos");
let btCalcular = document.querySelector ("#btCalcular");
let h3Resultado = document.querySelector ("#h3Resultado");

function CalcularFerraduras() {
    let cavalos = Number(inputcavalos.value);
    let ferraduras = cavalos * 4;
    
    h3Resultado.innerHTML = "Você vai precisar de: " + ferraduras + " ferraduras";
}
btCalcular.onclick = function() {
    CalcularFerraduras();
}