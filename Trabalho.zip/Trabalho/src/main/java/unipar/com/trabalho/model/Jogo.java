package unipar.com.trabalho.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Jogo {

    private Long id;

    private String titulo;

    private String genero;

    private Integer nota;

    private Boolean jogado;

}

