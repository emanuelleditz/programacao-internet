package unipar.com.trabalho.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import unipar.com.trabalho.model.Jogo;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/jogo")
public class JogoController {

    List<Jogo> bancoDados = new ArrayList<>();

    @GetMapping("/listar-todos")
    public ResponseEntity<List<Jogo>> listarTodos(@RequestParam(required = false) String genero,
                                                  @RequestParam(required = false) Boolean jogado,
                                                  @RequestParam(required = false) String titulo) {
        List<Jogo> jogosFiltrados = bancoDados.stream()
                .filter(j -> genero == null || j.getGenero().equalsIgnoreCase(genero))
                .filter(j -> jogado == null || j.getJogado().equals(jogado))
                .filter(j -> titulo == null || j.getTitulo().equalsIgnoreCase(titulo))
                .toList();

        return ResponseEntity.ok(jogosFiltrados);
    }


    @GetMapping("/buscar-id/{id}")
    public ResponseEntity<Jogo> buscarId(@PathVariable Long id){
        if (id == null){
            return ResponseEntity.badRequest().build();
        } else {
            Jogo jogoEncontrado = bancoDados.stream()
                    .filter(jogo -> jogo.getId().equals(id))
                    .findFirst()
                    .orElse(null);

            return ResponseEntity.ok(jogoEncontrado);
        }
    }


    @PostMapping("/cadastrar")
    public String cadastrarJogo(@RequestBody(required = false) Jogo jogo) {
        if (jogo == null) {
            return "Cadastro inválido, verifique novamente as informações!";
        } else {
            bancoDados.add(jogo);
            return "Jogo cadastrado com sucesso! " + jogo.getTitulo();
        }
    }


    @PutMapping("/editar/{id}") //editar
    public ResponseEntity<Jogo> editarJogo(@PathVariable Long id,
                                           @RequestBody(required = false) Jogo jogo) {
        if (jogo == null) {
            return ResponseEntity.noContent().build();
        } else {
            for (Jogo j : bancoDados) {
                if (j.getId().equals(id)) {
                    j.setTitulo(jogo.getTitulo());
                    j.setGenero(jogo.getGenero());
                    j.setJogado(jogo.getJogado());
                    j.setNota(jogo.getNota());
                    return ResponseEntity.ok(j);
                }
            }
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/deletar/{id}")
    public ResponseEntity deletarJogo(@PathVariable Long id) {
        boolean removido = bancoDados.removeIf(jogo -> jogo.getId().equals(id));
        if (removido) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

}
