let inputpaozinho = document.querySelector ("#paozinho");
let inputbroas = document.querySelector ("#broas")
let btCalcular = document.querySelector ("#btCalcular");
let h3Resultado = document.querySelector ("#h3Resultado");

function CalcularVendas() {
    let paozinho = Number(inputpaozinho.value);
    let broas = Number(inputbroas.value);

    let ValorPaes = paozinho * 0.12;
    let ValorBroas = broas * 1.50;
    let total = broas + paozinho;
    let poupanca = total * 0.10;
    
    h3Resultado.innerHTML = 
    "Total Arrecadado: R$" + total + "<br>" +
    "Valor para guardar na poupança (10%): R$" + poupanca; 
}
btCalcular.onclick = function() {
    CalcularVendas();
}