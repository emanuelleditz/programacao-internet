let inputsalario = document.querySelector ("#salario");
let btCalcular = document.querySelector ("#btCalcular");
let h3Resultado1 = document.querySelector ("#h3Resultado1");
let h3Resultado2 = document.querySelector ("#h3Resultado2");
let h3Resultado3 = document.querySelector ("#h3Resultado3");

function Calcular (){
    let salario = Number (inputsalario.value);

    let salarioAumento = (salario * 0.15) + salario;
    let salarioFinal = salarioAumento - (salarioAumento * 0.08);
 
    h3Resultado1.innerHTML = "O sal&aacute;rio inicial &eacute;: " + salario.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

    h3Resultado2.innerHTML = "O sal&aacute;rio com aumento &eacute;: " + salarioAumento.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

    h3Resultado3.innerHTML = "O sal&aacute;rio final &eacute;: " + salarioFinal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });


}

btCalcular.onclick = function(){
    Calcular();
}