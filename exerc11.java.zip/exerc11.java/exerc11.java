import java.util.Scanner;

public class exerc11 {
    public static void main (String[]args){
         //declaracao de variaveis
        double R;
        Scanner s = new Scanner(System.in);
        
        //solicitanto dados para o usuario
        
        System.out.println("Informe o valor do raio da esfera:");
        R  = s.nextDouble();
        
        //calculos
        
        double aoCubo;
        double volume;
        
        aoCubo = (R * R) * R;
        volume = (4.0/3.0) * Math.PI * aoCubo;
        
        System.out.print("Resultado: " + volume);

        
    }
}
