import java.util.Scanner;

public class exerc12 {
    public static void main (String[]args){
        int cont;
        cont = 53;

        while (cont <58 ) {
            System.out.println("Contador: " + cont);
            //cont++;
            cont = cont +1;
        }
    }
    
}
