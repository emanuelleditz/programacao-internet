//Exercício 1
let InputLadoX = document.querySelector("#LadoX");
let InputLadoY = document.querySelector("#LadoY");
let InputLadoZ = document.querySelector("#LadoZ");
let btVerificar = document.querySelector("#btVerificar");
let ResultadoTriangulo = document.querySelector("#ResultadoTriangulo");

function verificarTriangulo() {
    let LadoX = Number(InputLadoX.value);
    let LadoY = Number(InputLadoY.value);
    let LadoZ = Number(InputLadoZ.value);

    //VERIFICAR SE OS LADOS FORMAM UM TRIANGULO
    if (LadoX < LadoY + LadoZ && LadoY < LadoX + LadoZ && LadoZ < LadoX + LadoY) {
        if (LadoX === LadoY && LadoY === LadoZ) {
            ResultadoTriangulo.innerHTML = " Tri&acirc;ngulo Equil&aacute;tero: Todos os lados iguais.";
        }
        else if (LadoX === LadoY || LadoX === LadoZ || LadoY === LadoZ) {
            ResultadoTriangulo.innerHTML = " Tri&acirc;ngulo Is&oacute;sceles: Dois lados iguais.";
        }
        else {
            ResultadoTriangulo.innerHTML = " Tri&acirc;ngulo Escaleno: Todos os lados diferentes.";
        }
    }    
        else {
            ResultadoTriangulo.innerHTML = " Os valores informados n&atilde;o formam um tri&acirc;ngulo.";
        }

        
    
}

btVerificar.onclick = function () {
    verificarTriangulo();
}

//Exercício 2
let inputPeso = document.querySelector("#Peso");
let inputAltura = document.querySelector("#Altura");
let btImc = document.querySelector("#btImc");
let ResultadoIMC = document.querySelector("#ResultadoIMC");

function calcularIMC() {
    let Peso = Number(inputPeso.value);
    let Altura = Number(inputAltura.value);

    if (Peso > 0 && Altura > 0){
        let imc = Peso / (Altura * Altura);
        let classificacao = "";
        
        if (imc < 18.5) {
            classificacao = "Abaixo do peso.";
        } else if (imc < 25) {
            classificacao = "Peso normal.";
        } else if (imc < 30) {
            classificacao = "Sobrepeso.";
        } else if (imc < 35) {
            classificacao = "Obesidade grau 1.";
        } else if (imc < 40) {
            classificacao = "Obesidade grau 2.";
        } else {
            classificacao = "Obesidade grau 3.";
        }

        ResultadoIMC.innerHTML = "Seu IMC é <strong>" + imc.toFixed(2) + "</strong> = " + classificacao;
        
    }
    else {
        ResultadoIMC.innerHTML = "Por favor, insira valores v&aacute;lidos de peso e altura.";
    }
}
btImc.onclick = function () {
    calcularIMC();
}

//Exercício 3
let InputAno = document.querySelector("#Ano");
let InputValor = document.querySelector("#Valor");
let btImposto = document.querySelector("#btImposto");
let ResultadoImposto = document.querySelector("#ResultadoImposto");

function calcularImposto() {
    let Ano = Number(InputAno.value);
    let Valor = Number(InputValor.value);
       
    if (Ano > 0 && Valor > 0) {
        let taxa = (Ano < 1990) ? 0.01 : 0.015;
        let imposto = Valor * taxa;

        ResultadoImposto.innerHTML = `Ano: ${Ano}<br>
        Valor do carro: R$ ${Valor}<br>
        Taxa aplicada: ${taxa * 100}%<br>
        <strong>Imposto a pagar: R$ ${imposto}</strong>`;
    } else {
        ResultadoImposto.innerHTML = "Por favor, informe um ano e valor v&aacute;lidos.";

    }
}

btImposto.onclick = function () {
    calcularImposto();
};

//Exercício 4
let InputSalario = document.querySelector("#Salario");
let InputCodigo = document.querySelector("#Codigo");
let btSalario = document.querySelector("#btSalario");
let ResultadoSalario = document.querySelector("#ResultadoSalario");

function calcularSalarios() {
    let Salario = Number(InputSalario.value);
    let Codigo = Number(InputCodigo.value);
       
    if (Salario > 0) {
        let aumento = 0;
        let cargo = "";

        if (Codigo === 101) {
            aumento = 0.10;
            cargo = "Gerente";
        } else if (Codigo === 102) {
            aumento = 0.20;
            cargo = "Engenheiro";
        } else if (Codigo === 103) {
            aumento = 0.30;
            cargo = "Técnico";
        } else {
            aumento = 0.40;
            cargo = "Cargo não listado";
        }

        let novoSalario = Salario * (1 + aumento);
        let diferenca = novoSalario - Salario;

        ResultadoSalario.innerHTML = `
        Cargo: ${cargo}<br>
        Sal&aacute;rio antigo: R$ ${Salario}<br>
        Novo sal&aacute;rio: R$ ${novoSalario}<br>
        Aumento: R$ ${diferenca} (${(aumento * 100)}%)`;
    } else {
        ResultadoSalario.innerHTML = "Por favor, insira um sal&aacute;rio v&aacute;lido.";
    }
}

btSalario.onclick = function () {
    calcularSalarios();
};

//Exercício 5
let inputSaldo = document.querySelector("#saldoMedio");
let botao = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultadoCredito");

function calcularCredito() {
    let saldo = Number(inputSaldo.value);
    let percentual = 0;
    let mensagem = "";

    if (saldo <= 0) {
        resultado.innerHTML = "Por favor, insira um saldo v&aacute;lido.";
        return;
    }

    if (saldo <= 200) {
        percentual = 0;
        mensagem = "Nenhum cr&eacute;dito concedido.";
    } else if (saldo <= 400) {
        percentual = 0.20;
    } else if (saldo <= 600) {
        percentual = 0.30;
    } else {
        percentual = 0.40;
    }

    if (percentual > 0) {
        let credito = saldo * percentual;
        mensagem = `Saldo m&eacute;dio: R$ ${saldo.toFixed(2).replace('.', ',')}<br>
                    Cr&eacute;dito concedido: R$ ${credito.toFixed(2).replace('.', ',')} (${percentual * 100}%)`;
    }

    resultado.innerHTML = mensagem;
}

botao.onclick = calcularCredito;

//Exercício 6
let inputCodigo = document.querySelector("#codigo");
let inputQuantidade = document.querySelector("#quantidade");
let btLanchonete = document.querySelector("#btLanchonete");
let resultadoLanchonete = document.querySelector("#resultadoLanchonete");

function calcularTotal() {
    let codigo = Number(inputCodigo.value);
    let quantidade = Number(inputQuantidade.value);
    let preco = 0;
    let produto = "";

    if (quantidade <= 0 || isNaN(codigo)) {
        resultadoLanchonete.innerHTML = "Por favor, preencha os dados corretamente.";
        return;
    }

    switch (codigo) {
        case 1:
            preco = 11.00;
            produto = "Cachorro Quente";
            break;
        case 2:
            preco = 8.50;
            produto = "Bauru";
            break;
        case 3:
            preco = 8.00;
            produto = "Misto Quente";
            break;
        case 4:
            preco = 9.00;
            produto = "Hamb&uacute;rguer";
            break;
        case 5:
            preco = 10.00;
            produto = "Cheeseburger";
            break;
        case 6:
            preco = 4.50;
            produto = "Refrigerante";
            break;
        default:
            resultadoLanchonete.innerHTML = "C&oacute;digo inv&aacute;lido.";
            return;
    }

    let total = preco * quantidade;

    resultadoLanchonete.innerHTML = `Produto: ${produto}<br>
                           Quantidade: ${quantidade}<br>
                           Total a pagar: R$ ${total.toFixed(2).replace('.', ',')}`;
}

btLanchonete.onclick = calcularTotal;

//Exercício 7 
let inputPreco = document.querySelector("#preco");
let selectCondicao = document.querySelector("#condicao");
let btCalcularVendas = document.querySelector("#btCalcularVendas");
let resultadoVendas = document.querySelector("#resultadoVendas");

function calcularVenda() {
    let preco = Number(inputPreco.value);
    let condicao = selectCondicao.value;
    let total = 0;
    let descricao = "";

    if (preco <= 0 || !condicao) {
        resultadoVendas.innerHTML = "Por favor, informe o pre&ccedil;o e a condi&ccedil;&atilde;o de pagamento.";
        return;
    }

    switch (condicao) {
        case "a":
            total = preco * 0.90;
            descricao = "À vista em dinheiro ou cheque (10% de desconto)";
            break;
        case "b":
            total = preco * 0.85;
            descricao = "À vista no cartão de crédito (15% de desconto)";
            break;
        case "c":
            total = preco;
            descricao = "Em duas vezes (sem juros)";
            break;
        case "d":
            total = preco * 1.10;
            descricao = "Em duas vezes (com 10% de juros)";
            break;
        default:
            resultadoVendas.innerHTML = "Condi&ccedil;&atilde;o de pagamento inv&aacute;lida.";
            return;
    }

    resultadoVendas.innerHTML = `
        Condição: ${descricao}<br>
        Valor final: R$ ${total.toFixed(2).replace('.', ',')}
    `;
}

btCalcularVendas.onclick = calcularVenda;

//Exercício 8
let selectNivel = document.querySelector("#nivel");
let inputHoras = document.querySelector("#horas");
let btCalcularProf = document.querySelector("#btCalcularProf");
let resultadoProf = document.querySelector("#resultadoProf");

function calcularSalario() {
    let nivel = selectNivel.value;
    let horas = Number(inputHoras.value);
    let valorHora = 0;

    if (!nivel || horas <= 0) {
        resultadoProf.innerHTML = "Por favor, preencha os dados corretamente.";
        return;
    }

    switch (nivel) {
        case "1":
            valorHora = 12.00;
            break;
        case "2":
            valorHora = 17.00;
            break;
        case "3":
            valorHora = 25.00;
            break;
        default:
            resultadoProf.innerHTML = "N&iacute;vel inv&aacute;lido.";
            return;
    }

    let salario = valorHora * horas * 4.5;

    resultadoProf.innerHTML = `
        N&iacute;vel: ${nivel}<br>
        Valor hora/aula: R$ ${valorHora.toFixed(2).replace('.', ',')}<br>
        Total de horas/semana: ${horas}<br>
        Sal&aacute;rio mensal: R$ ${salario.toFixed(2).replace('.', ',')}
    `;
}

btCalcularProf.onclick = calcularSalario;