import java.util.Scanner;

public class exerc8 {
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);

        double leitura_relogio_inicial, leitura_relogio_final;
        double media, consumo;

        System.out.print("Informe o valor do relogio de agua no 1 dia: ");
        leitura_relogio_inicial = s.nextDouble();
        System.out.print("Informe o valor do relogio de agua no 30 dia: ");
        leitura_relogio_final = s.nextDouble();

        consumo = leitura_relogio_final - leitura_relogio_inicial;
        media = consumo / 30;

        System.out.print("Litros consumidos: " + consumo + "\nMedia diaria: " + media);

    }
}
