import java.util.Scanner;

public class exerc13 {
    public static void main (String[]args){

        int cont;
        cont = 5;

        System.out.println("Exemplo while: ");
        while (cont <5) {
            System.out.println("Contador: " + cont);
            //cont++;
            cont = cont +1;
        }    

        System.out.println("Exemplo do: ");
        cont = 5;
        do{
                System.out.println("Contador: " + cont);
                cont++;
            } while (cont <5);
       }
}
    