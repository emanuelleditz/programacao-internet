let inputquilo = document.querySelector ("#quilo");
let btCalcular = document.querySelector ("#btCalcular");
let h3Resultado = document.querySelector ("#h3Resultado");

function CalcularQuilo (){
    let quilo = Number (inputquilo.value);

    let resultado = quilo * 12.00;

    h3Resultado.innerHTML = "Valor total a pagar &eacute;: " + resultado.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

btCalcular.onclick = function(){
    CalcularQuilo();
}